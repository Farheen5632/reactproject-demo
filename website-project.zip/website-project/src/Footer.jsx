function Footer() {
  return (
    <>
      <footer className="bg-dark text-white text-center p-3 mt-auto">
        <p>&copy; 2025 My React Website. All rights reserved.</p>
      </footer>
    </>
  );
}
export default Footer;
