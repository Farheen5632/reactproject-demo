function Header() {
  return (
    <>
     <header className="bg-primary text-white text-center py-4">
  <h1>My Personal Profile</h1>
  <p>A personal website built with React and Bootstrap.</p>
</header>

    </>
  );
}
export default Header;
